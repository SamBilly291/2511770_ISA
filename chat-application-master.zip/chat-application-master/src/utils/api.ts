export const API = "https://xchat.universalchemistrynetwork.com/xcapi";
export const SOCKET_API = "https://xchat.universalchemistrynetwork.com/";
